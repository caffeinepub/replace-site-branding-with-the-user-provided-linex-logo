# Specification

## Summary
**Goal:** Clarify that there is no specific application change requested in this iteration (empty BuildRequest).

**Planned changes:**
- None

**User-visible outcome:** No user-visible changes.
