export default function BrandsBanner() {
  const brands = [
    { name: 'Phoenix Contact logo', src: '/assets/brands/csm_Phoenix_Contact_767777eeeb-3.png' },
    { name: 'Delta Electronics logo', src: '/assets/brands/delta-electronics-logo-delta-air-lines-power-converters-electronics-3.jpg' },
    { name: 'Mitsubishi Electric logo', src: '/assets/brands/Mitsubishi_Electric_logo.svg_-3.png' },
    { name: 'Siemens logo', src: '/assets/brands/siemens-logo-2.png' },
    { name: 'Lauritz Knudsen logo', src: '/assets/brands/lk-logo-3.png' },
    { name: 'Schneider Electric logo', src: '/assets/brands/Schneider-Electric-logo-jpg--3.png' },
  ];

  return (
    <section className="border-t border-border/40 bg-background py-12 md:py-16">
      <div className="container">
        <h2 className="mb-8 text-center text-2xl font-bold tracking-tight sm:text-3xl">
          Brands We Deal In
        </h2>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {brands.map((brand, index) => (
            <div
              key={index}
              className="flex h-20 w-40 items-center justify-center grayscale transition-all hover:grayscale-0"
            >
              <img
                src={brand.src}
                alt={brand.name}
                className="h-full w-full object-contain"
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
